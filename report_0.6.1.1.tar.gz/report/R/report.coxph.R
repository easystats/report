#' @include report.lm.R
#' @export
report.coxph <- report.lm

#' @export
report_effectsize.coxph <- report_effectsize.lm

#' @export
report_table.coxph <- report_table.lm

#' @export
report_statistics.coxph <- report_statistics.lm

#' @export
report_parameters.coxph <- report_parameters.lm

#' @export
report_intercept.coxph <- report_intercept.lm

#' @export
report_model.coxph <- report_model.lm

#' @export
report_performance.coxph <- report_performance.lm

#' @export
report_info.coxph <- report_info.lm

#' @export
report_text.coxph <- report_text.lm
