#' @include report.lm.R
#' @export
report.survreg <- report.lm

#' @export
report_effectsize.survreg <- report_effectsize.lm

#' @export
report_table.survreg <- report_table.lm

#' @export
report_statistics.survreg <- report_statistics.lm

#' @export
report_parameters.survreg <- report_parameters.lm

#' @export
report_intercept.survreg <- report_intercept.lm

#' @export
report_model.survreg <- report_model.lm

#' @export
report_performance.survreg <- report_performance.lm

#' @export
report_info.survreg <- report_info.lm

#' @export
report_text.survreg <- report_text.lm
