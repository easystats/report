#' @include report.lm.R
#' @export
report.ivreg <- report.lm

#' @export
report_effectsize.ivreg <- report_effectsize.lm

#' @export
report_table.ivreg <- report_table.lm

#' @export
report_statistics.ivreg <- report_statistics.lm

#' @export
report_parameters.ivreg <- report_parameters.lm

#' @export
report_intercept.ivreg <- report_intercept.lm

#' @export
report_model.ivreg <- report_model.lm

#' @export
report_performance.ivreg <- report_performance.lm

#' @export
report_info.ivreg <- report_info.lm

#' @export
report_text.ivreg <- report_text.lm
