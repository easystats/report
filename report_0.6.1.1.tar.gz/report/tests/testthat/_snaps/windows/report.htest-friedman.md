# report.htest-friendman report

    Code
      report(x)
    Output
      Effect sizes were labelled following Landis' (1977) recommendations.
      
      The Friedman rank sum test testing the difference in ranks between wb$x, wb$w,
      and wb$t suggests that the effect is statistically not significant, and in
      slight agreement (chi2 = 0.33, p = 0.564; Kendall's W = 0.11, 95% CI [0.11,
      1.00])

