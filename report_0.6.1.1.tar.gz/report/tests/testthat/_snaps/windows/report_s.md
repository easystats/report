# report_s

    Code
      report_s(s = 4.2)
    Message
      If the test hypothesis (parameter = 0) and all model assumptions were
        true, there is a 5.4% chance of observing this outcome. How weird is
        that? It's hardly more surprising than getting 4 heads in a row with
        fair coin tosses.

---

    Code
      report_s(p = 0.06)
    Message
      If the test hypothesis (parameter = 0) and all model assumptions were
        true, there is a 6% chance of observing this outcome. How weird is that?
        It's hardly more surprising than getting 4 heads in a row with fair coin
        tosses.

