# report.htest-fisher report

    Code
      report(x)
    Output
      Effect sizes were labelled following Funder's (2019) recommendations.
      
      The Fisher's Exact Test for Count Data testing the association between the
      variables of the TeaTasting dataset suggests that the effect is statistically
      not significant, and large (odds ratio = 6.41, 95% CI [0.31, Inf], p = 0.243;
      Adjusted Cramer's v = 0.35, 95% CI [0.00, 1.00])

